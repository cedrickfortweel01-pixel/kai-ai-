# Kobe AI Intelligence (KAI) — first implementation

This is a separate development project. It does not connect to the live Kobe Mweusi database or perform financial actions.

## First milestone
- Cloudflare Worker API gateway
- DeepSeek API integration (server-side secret)
- Health endpoint
- Authenticated `/api/analyze` endpoint
- Structured JSON response and input limits

## Requirements
- Node.js LTS
- npm
- Cloudflare account
- DeepSeek API key

## 1. Install
```bash
npm install
```

## 2. Configure the model
Copy `.dev.vars.example` to `.dev.vars`, then add your DeepSeek API key.
Choose a model ID currently enabled for your DeepSeek account. The default `deepseek-flash` is configurable. Use `deepseek-v4-pro` only when you later add a deliberate escalation path. Check the current model list in the DeepSeek API docs before deploying.

```bash
cp .dev.vars.example .dev.vars
```

Never commit `.dev.vars`.

## 3. Run locally
```bash
npm run dev
```
The Worker runs at the local URL shown by Wrangler, normally http://localhost:8787.

Health check:
```bash
curl http://localhost:8787/health
```

Analysis test (replace the development token):
```bash
curl -X POST http://localhost:8787/api/analyze \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer replace-with-a-long-random-token" \
  -d '{"task":"classify_incident","incident":{"type":"suspicious_login","failed_attempts":18,"window_minutes":5,"affected_accounts":2}}'
```

## 4. Deploy only after local testing
```bash
npx wrangler login
npx wrangler secret put DEEPSEEK_API_KEY
npx wrangler secret put KAI_ACCESS_TOKEN
npx wrangler deploy
```
Set `DEEPSEEK_MODEL` in `wrangler.toml` to a model ID supported by your DeepSeek account, or update it through Worker configuration.

## Important safety boundaries
- This Worker is an analysis gateway, not a transaction authority.
- Do not send passwords, PINs, NIDA images, payment credentials, access tokens, or raw QR secrets to the model.
- Never let model output execute account freezes, payouts, wallet adjustments, KYC approvals or escrow releases.
- Deterministic backend validation must reject invalid payments and QR replays independently of AI.
- Before production, replace the simple bearer-token gate with authenticated service-to-service requests, scoped identities, rotation and rate limits.
- Add Supabase staging only in the next milestone. Do not point this starter at production.
