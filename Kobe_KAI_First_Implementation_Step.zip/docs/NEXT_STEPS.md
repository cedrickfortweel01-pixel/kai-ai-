# Next implementation milestones

## Milestone 1 — Gateway (this starter)
- [ ] Install dependencies
- [ ] Add local DeepSeek key and KAI bearer token
- [ ] Run `/health`
- [ ] Test `/api/analyze` with synthetic data
- [ ] Confirm the API usage field is returned

## Milestone 2 — Separate Supabase staging
- Create a new Supabase project for KAI development.
- Add a migration under `supabase/migrations/`.
- Create the proposed `kobe_intelligence` schema and tables.
- Deny `anon` and ordinary `authenticated` access by default.
- Access tables only through narrowly scoped server-side functions.
- Test permissions before importing any real events.

## Milestone 3 — Event ingestion
- Accept signed events from trusted backend services only.
- Validate event type and payload schema.
- Redact secrets and unnecessary personal data before persistence or AI analysis.
- Deduplicate using an idempotency key/fingerprint.

## Milestone 4 — Rules before AI
- Implement deterministic checks for payment callback verification, QR replay, escrow state and login rate limits.
- Store an incident when a rule fires.
- Call DeepSeek only for selected incidents or scheduled summaries.

## Milestone 5 — Support assistant (separate service)
- Integrate OpenRouter in a separate Worker/service.
- Start with the `openrouter/free` router, checking current availability and limits.
- Ground answers in approved help-centre content.
- Escalate payment, account access, disputes and safety-sensitive issues to human support.
- Never give the support model access to KAI secrets or privileged database tools.

## Milestone 6 — Notifications and dashboard
- Add Telegram and email dispatch queues.
- Add dashboard incident views and approval workflows.
- Keep a durable record even when a notification provider is down.

## Production gate
Do not connect to production until authentication, RLS, rate limits, budget controls, audit logs, retention, failure handling and adversarial tests have passed.
